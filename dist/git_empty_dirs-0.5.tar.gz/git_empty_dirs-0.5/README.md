Utility for enabling commit for empty directories.
